<template>
  <div>
  </div>
</template>

<script>
export default {
  name: 'HallOfRespect',
}
</script>

<style scoped>
</style>
